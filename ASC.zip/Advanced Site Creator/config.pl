##############################################################################
##			Advanced Site Creator v 1.0     	    	    ##
##									    ##
##  Este cgi � gr�tis e pode ser pego em http://www.webinf.com.br/script    ##
##  e n�o deve ser vendido, mas qualquer doa��o eu aceito, s� falar comigo  ##
##  :-) icq: 76656023							    ##
##  									    ##
##  									    ##
##  Criado e desenvolvido por: Waldir A. Pedroso			    ##
##  E-mail: webinf@webinf.com.br					    ##
##  									    ##
##############################################################################
##############################################################################
## 		   	      Configura��es		    		    ##
##############################################################################

$senhaadmin = "teste";			 # Senha do administrador
$siteurl = "http://www.webinf.com.br";   # URL do seu Site
$titulo = "Web Inf - Script";            # T�tulo do seu Site
$dirfig = "./figuras";	 # Path para o diret�rio para a pasta das imagens


##############################################################################
## 		   	     N�o mude nada aqui	    		    	    ##
##############################################################################
